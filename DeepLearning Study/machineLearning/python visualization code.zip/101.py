# Import pandas as a alias 'pd'
import ______ as __

# Load the CSV file "marathon_results_2017.csv" under "data" folder
marathon_2017 = __.________("______marathon_results_2017.csv")

# Display the first five initial rows using the .head() method
print(marathon_2017._______)

# Display data frame structure using the .info() method
print(marathon_2017._______)
