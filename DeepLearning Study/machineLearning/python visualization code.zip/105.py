# Add Senior column with boolean value whether age is more than 60 or not
marathon_2017_clean[_______] = marathon_2017_clean.____ _ __

# Display updated data frame with .head() method
print(marathon_2017_clean.head())

# Add Year column with fixed string 2017
marathon_2017_clean[______] = _____

# Display updated data frame with .head() method
print(marathon_2017_clean.head())
