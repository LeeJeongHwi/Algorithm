# Select the column by dot notation
names = marathon_2017_clean._____

# Display names
print(names)

# Select the column by brackets notation
official_time = marathon_2017_clean[________]

# Display Official Time
print(official_time)
