# Select runner who's age is more than 60
seniors = marathon_2017_clean.____ _ __

# Display seniors
print(seniors)

# Select runners from Kennay by conditional expression
KEN_runner = marathon_2017_clean[___________.__________ __ _____]

# Display runners from Kennay
print(KEN_runner)
